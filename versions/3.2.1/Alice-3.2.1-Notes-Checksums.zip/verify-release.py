PUBLIC_KEY='EPlwMn9VYhjg1jUYEEOg4dKx5UonGZQaYIPI2S4WrgY='
from pathlib import Path
import base64,hashlib,json
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
folder=Path(__file__).resolve().parent
public=base64.b64decode(PUBLIC_KEY)
data=(folder/'release-files.json').read_bytes()
Ed25519PublicKey.from_public_bytes(public).verify((folder/'release-files.sig').read_bytes(),b'AliceReleaseFiles/v1\x00'+data)
info=json.loads(data)
expected={'AliceDeveloper.exe','AliceDeveloper-Setup.exe'} if info['version'].endswith('v') else {'Alice.exe','Alice-Setup.exe'}
assert info['schema']==1 and set(info['files'])==expected
for name,digest in info['files'].items():
    assert hashlib.sha256((folder/name).read_bytes()).hexdigest()==digest, 'File modified: '+name
print('Alice '+info['version']+' release files verified')
